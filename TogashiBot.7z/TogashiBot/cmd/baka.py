info = {
    "name": "baka",
    "version": "1.0.0",
    "description": "baka",
    "example": "/baka",
    "credit": "Muhammad MuQiT",
    "hasPermission": 0,
    "cooldown": 0
}

async def baka(api, threadID, thread_type, **kwargs):
    api.sendMessage("Bakaaa!! Hentai!!! echhiiii dorobokeno shinee!", threadID, thread_type)
